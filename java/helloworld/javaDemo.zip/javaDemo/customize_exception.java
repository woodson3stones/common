public class customize_exception extends Exception{//compile exception need try catch 
	public customize_exception(){}
	public customize_exception(String message){
		super(message);
	}
}