public interface my_interface {
	public static final boolean married=true; //<=> constant value
	public abstract void get_married();//<=> void get_married();
}